nota = float(input("Hey, como te fue en el examen de ese cucho... : "))

if nota >= 4.0: 
    print("Le gane a ese perro")
else:
    print("Me tire la nota")
